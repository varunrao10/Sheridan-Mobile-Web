// myscript.js for selectorsActions.html
// 1191 Updated
